import React, { useState, useEffect } from 'react';

const TARGET_DATE = new Date('2026-02-14T15:30:00').getTime();

const Countdown: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number }>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().getTime();
      const distance = TARGET_DATE - now;

      if (distance < 0) {
        clearInterval(interval);
        return;
      }

      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000)
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const TimeUnit: React.FC<{ value: number; label: string }> = ({ value, label }) => (
    <div className="flex flex-col items-center">
      <div className="w-14 h-14 sm:w-16 sm:h-16 bg-white/50 backdrop-blur-sm rounded-2xl shadow-sm border border-white flex items-center justify-center mb-1">
        <span className="text-xl sm:text-2xl font-bold text-gray-700 font-heading">{String(value).padStart(2, '0')}</span>
      </div>
      <span className="text-[10px] sm:text-xs text-gray-500 font-bold uppercase tracking-widest">{label}</span>
    </div>
  );

  return (
    <div className="flex gap-3 sm:gap-6 justify-center mb-8 animate-fade-in-up">
        <TimeUnit value={timeLeft.days} label="Dias" />
        <div className="pt-2 text-gray-300 font-bold text-xl">:</div>
        <TimeUnit value={timeLeft.hours} label="Hrs" />
        <div className="pt-2 text-gray-300 font-bold text-xl">:</div>
        <TimeUnit value={timeLeft.minutes} label="Min" />
        <div className="pt-2 text-gray-300 font-bold text-xl">:</div>
        <TimeUnit value={timeLeft.seconds} label="Seg" />
    </div>
  );
};

export default Countdown;