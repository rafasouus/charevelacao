import React from 'react';
import { Vote, Gender } from '../types';
import { User, Download, Table } from 'lucide-react';

interface GuestListProps {
  votes: Vote[];
}

const GuestList: React.FC<GuestListProps> = ({ votes }) => {
  if (votes.length === 0) return null;

  // Reverse to show newest first
  const displayVotes = [...votes].reverse();

  const exportToCSV = () => {
    // BOM for Excel to recognize UTF-8 properly
    const BOM = "\uFEFF"; 
    const headers = ["Data", "Nome", "Palpite", "Mensagem da IA"];
    
    const csvRows = votes.map(vote => {
      // Escape quotes in strings to avoid CSV breakage
      const safeName = vote.name.replace(/"/g, '""');
      const safeMessage = (vote.aiMessage || "").replace(/"/g, '""');
      const guessText = vote.guess === Gender.BOY ? "MIGUEL (Menino)" : "CATARINA (Menina)";
      
      return [
        `"${vote.timestamp}"`,
        `"${safeName}"`,
        `"${guessText}"`,
        `"${safeMessage}"`
      ].join(",");
    });

    const csvContent = BOM + headers.join(",") + "\n" + csvRows.join("\n");
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'palpites_cha_revelacao.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="w-full bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 mt-8 mb-12">
      <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
            <div className="bg-indigo-100 p-2 rounded-lg text-indigo-600">
                <Table size={20} />
            </div>
            <div>
                <h3 className="font-heading font-bold text-gray-700">Planilha de Palpites</h3>
                <p className="text-xs text-gray-400 hidden sm:block">Registro dos votos da galera</p>
            </div>
        </div>
        
        <button 
            onClick={exportToCSV}
            className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white text-sm font-bold px-4 py-2 rounded-xl shadow-sm transition-transform active:scale-95 w-full sm:w-auto justify-center"
            title="Baixar lista em Excel/CSV"
        >
            <Download size={16} />
            Baixar Planilha
        </button>
      </div>
      
      <div className="overflow-x-auto max-h-96 overflow-y-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-gray-500 uppercase bg-gray-50 sticky top-0 shadow-sm z-10">
            <tr>
              <th scope="col" className="px-6 py-3">Data</th>
              <th scope="col" className="px-6 py-3">Nome</th>
              <th scope="col" className="px-6 py-3">Palpite</th>
              <th scope="col" className="px-6 py-3 hidden sm:table-cell">Mensagem da IA</th>
            </tr>
          </thead>
          <tbody>
            {displayVotes.map((vote) => (
              <tr key={vote.id} className="bg-white border-b hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 text-gray-400 font-mono text-xs whitespace-nowrap">{vote.timestamp}</td>
                <td className="px-6 py-4 font-bold text-gray-700 flex items-center gap-2">
                  <User size={14} className="text-gray-400" />
                  {vote.name}
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-bold border ${
                    vote.guess === Gender.BOY 
                      ? 'bg-blue-50 text-blue-600 border-blue-200' 
                      : 'bg-pink-50 text-pink-600 border-pink-200'
                  }`}>
                    {vote.guess === Gender.BOY ? 'MIGUEL' : 'CATARINA'}
                  </span>
                </td>
                <td className="px-6 py-4 text-gray-500 italic hidden sm:table-cell truncate max-w-xs" title={vote.aiMessage}>
                  {vote.aiMessage || '-'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default GuestList;