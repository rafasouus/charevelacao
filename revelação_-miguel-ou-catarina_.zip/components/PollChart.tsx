import React from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { Vote, Gender, StatData } from '../types';
import { Trophy } from 'lucide-react';

interface PollChartProps {
  votes: Vote[];
}

const PollChart: React.FC<PollChartProps> = ({ votes }) => {
  const miguelCount = votes.filter(v => v.guess === Gender.BOY).length;
  const catarinaCount = votes.filter(v => v.guess === Gender.GIRL).length;
  const total = miguelCount + catarinaCount;

  // Calculate percentages
  const miguelPercent = total === 0 ? 0 : Math.round((miguelCount / total) * 100);
  const catarinaPercent = total === 0 ? 0 : Math.round((catarinaCount / total) * 100);

  const data: StatData[] = [
    { name: 'Miguel', value: miguelCount, fill: '#5CA0D3' },
    { name: 'Catarina', value: catarinaCount, fill: '#D86B99' },
  ];

  if (total === 0) {
    return (
      <div className="w-full bg-white/70 backdrop-blur-md rounded-2xl shadow-sm border border-white p-8 flex flex-col items-center justify-center text-center h-64">
        <div className="bg-gray-100 p-4 rounded-full mb-3 text-gray-400">
            <Trophy size={32} />
        </div>
        <p className="text-gray-500 font-medium">O placar está zerado!</p>
        <p className="text-sm text-gray-400">Seja o primeiro a votar.</p>
      </div>
    );
  }

  return (
    <div className="w-full bg-white/70 backdrop-blur-md rounded-2xl shadow-sm border border-white p-6 flex flex-col items-center">
      <h3 className="text-lg font-heading font-bold text-gray-800 mb-4 w-full text-left flex items-center gap-2">
        <Trophy size={18} className="text-yellow-500" />
        Placar da Galera
      </h3>
      
      <div className="w-full h-56 relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              paddingAngle={5}
              dataKey="value"
              cornerRadius={8}
              stroke="none"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              itemStyle={{ fontWeight: 'bold' }}
            />
          </PieChart>
        </ResponsiveContainer>
        
        {/* Center Text */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center">
            <span className="block text-3xl font-heading font-bold text-gray-700">{total}</span>
            <span className="text-xs text-gray-400 uppercase font-bold tracking-wider">Votos</span>
        </div>
      </div>

      {/* Custom Legend / Scoreboard */}
      <div className="w-full grid grid-cols-2 gap-4 mt-2">
         <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 flex flex-col items-center">
            <span className="text-xs text-blue-400 font-bold uppercase mb-1">Time Miguel</span>
            <div className="flex items-end gap-1">
                <span className="text-2xl font-bold text-blue-600">{miguelPercent}%</span>
                <span className="text-sm text-blue-400 mb-1 font-medium">({miguelCount})</span>
            </div>
            <div className="w-full bg-blue-200 h-1.5 rounded-full mt-2 overflow-hidden">
                <div className="bg-blue-500 h-full rounded-full transition-all duration-1000" style={{ width: `${miguelPercent}%` }}></div>
            </div>
         </div>

         <div className="bg-pink-50 border border-pink-100 rounded-xl p-3 flex flex-col items-center">
            <span className="text-xs text-pink-400 font-bold uppercase mb-1">Time Catarina</span>
            <div className="flex items-end gap-1">
                <span className="text-2xl font-bold text-pink-600">{catarinaPercent}%</span>
                <span className="text-sm text-pink-400 mb-1 font-medium">({catarinaCount})</span>
            </div>
             <div className="w-full bg-pink-200 h-1.5 rounded-full mt-2 overflow-hidden">
                <div className="bg-pink-500 h-full rounded-full transition-all duration-1000" style={{ width: `${catarinaPercent}%` }}></div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default PollChart;