import React, { useState } from 'react';
import { Send, PartyPopper, Bot } from 'lucide-react';
import { Gender, Vote } from '../types';
import { generateFunPrediction } from '../services/geminiService';

interface VotingFormProps {
  onVote: (vote: Vote) => void;
}

const VotingForm: React.FC<VotingFormProps> = ({ onVote }) => {
  const [name, setName] = useState('');
  const [selectedGender, setSelectedGender] = useState<Gender | null>(null);
  const [loading, setLoading] = useState(false);
  const [lastMessage, setLastMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !selectedGender) return;

    setLoading(true);
    setLastMessage(null);

    // Get AI fun message
    const aiResponse = await generateFunPrediction(name, selectedGender);

    const newVote: Vote = {
      id: Date.now().toString(),
      name: name.trim(),
      guess: selectedGender,
      timestamp: new Date().toLocaleDateString('pt-BR'),
      aiMessage: aiResponse
    };

    onVote(newVote);
    setLastMessage(aiResponse);
    setLoading(false);
    setName('');
    setSelectedGender(null);
  };

  return (
    <div className="w-full h-full">
      <div className="bg-white/80 backdrop-blur-xl border border-white rounded-3xl shadow-xl overflow-hidden h-full flex flex-col">
        <div className="p-6 md:p-8 flex-1">
          <h2 className="text-2xl md:text-3xl font-heading font-black text-gray-800 text-center mb-2">
            Qual é o seu palpite?
          </h2>
          <p className="text-center text-gray-500 mb-8">Escolha um time e deixe a IA criar uma previsão mágica!</p>
          
          <form onSubmit={handleSubmit} className="space-y-8">
            <div>
              <label htmlFor="name" className="block text-sm font-bold text-gray-600 mb-2 ml-1">
                Como devemos te chamar?
              </label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Ex: Titia Maria, Vovô João..."
                className="w-full px-5 py-4 rounded-xl border border-gray-200 bg-gray-50/50 focus:bg-white focus:border-indigo-400 focus:ring-4 focus:ring-indigo-100 transition-all outline-none text-lg text-gray-700 placeholder:text-gray-400"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4 md:gap-6">
              {/* Boy Option */}
              <button
                type="button" 
                onClick={() => setSelectedGender(Gender.BOY)}
                className={`relative group rounded-2xl border-2 p-6 flex flex-col items-center justify-center transition-all duration-300 ${
                  selectedGender === Gender.BOY 
                    ? 'border-blue-400 bg-blue-50/80 shadow-[0_0_20px_rgba(59,130,246,0.3)] scale-[1.02] ring-2 ring-blue-200 ring-offset-2' 
                    : 'border-gray-100 bg-white hover:border-blue-200 hover:shadow-lg hover:-translate-y-1'
                }`}
              >
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 transition-colors ${selectedGender === Gender.BOY ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-400 group-hover:bg-blue-200'}`}>
                   {/* Custom SVG Icon for Boy */}
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-10 h-10">
                      <path d="M15.75 8.25a.75.75 0 01.75.75c0 1.12-.492 2.126-1.27 2.812a.75.75 0 11-1.004-1.124A2.245 2.245 0 0015 9a.75.75 0 01.75-.75z" />
                      <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zM6.106 17.494a.75.75 0 01.636-.28l.006-.001a1.49 1.49 0 00.74-.235 3.743 3.743 0 013.911-.37c.758.375 1.579.596 2.455.626a.75.75 0 01.037 1.499c-1.096-.038-2.124-.314-3.072-.782a5.243 5.243 0 00-5.48.517.75.75 0 01-1.066-.974l1.833-2.001zM11.25 9a.75.75 0 01.75-.75h.008a.75.75 0 01.75.75v3a.75.75 0 01-.75.75h-.008a.75.75 0 01-.75-.75V9z" clipRule="evenodd" />
                   </svg>
                </div>
                <span className={`font-heading font-black text-xl transition-colors ${selectedGender === Gender.BOY ? 'text-blue-600' : 'text-gray-400 group-hover:text-blue-400'}`}>Miguel</span>
                <span className="text-xs font-bold tracking-widest text-blue-300 mt-1 uppercase">Menino</span>
                
                {selectedGender === Gender.BOY && (
                  <div className="absolute top-3 right-3 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white animate-bounce">
                    <Send size={12} className="rotate-45" />
                  </div>
                )}
              </button>

              {/* Girl Option */}
              <button
                type="button" 
                onClick={() => setSelectedGender(Gender.GIRL)}
                className={`relative group rounded-2xl border-2 p-6 flex flex-col items-center justify-center transition-all duration-300 ${
                  selectedGender === Gender.GIRL 
                    ? 'border-pink-400 bg-pink-50/80 shadow-[0_0_20px_rgba(236,72,153,0.3)] scale-[1.02] ring-2 ring-pink-200 ring-offset-2' 
                    : 'border-gray-100 bg-white hover:border-pink-200 hover:shadow-lg hover:-translate-y-1'
                }`}
              >
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 transition-colors ${selectedGender === Gender.GIRL ? 'bg-pink-500 text-white' : 'bg-pink-100 text-pink-400 group-hover:bg-pink-200'}`}>
                   {/* Custom SVG Icon for Girl */}
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-10 h-10">
                      <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                   </svg>
                </div>
                <span className={`font-heading font-black text-xl transition-colors ${selectedGender === Gender.GIRL ? 'text-pink-600' : 'text-gray-400 group-hover:text-pink-400'}`}>Catarina</span>
                <span className="text-xs font-bold tracking-widest text-pink-300 mt-1 uppercase">Menina</span>

                {selectedGender === Gender.GIRL && (
                  <div className="absolute top-3 right-3 w-6 h-6 bg-pink-500 rounded-full flex items-center justify-center text-white animate-bounce">
                    <Send size={12} className="rotate-45" />
                  </div>
                )}
              </button>
            </div>

            <button
              type="submit"
              disabled={loading || !name || !selectedGender}
              className={`w-full py-4 rounded-xl font-bold text-lg text-white shadow-xl flex items-center justify-center gap-2 transition-all transform hover:shadow-2xl active:scale-95 ${
                loading 
                  ? 'bg-gray-400 cursor-wait' 
                  : 'bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 hover:brightness-110'
              }`}
            >
              {loading ? (
                <span className="animate-pulse">Consultando os astros...</span>
              ) : (
                <>
                  <Send size={20} className={!selectedGender ? "opacity-50" : ""} />
                  Confirmar Voto
                </>
              )}
            </button>
          </form>

          {/* Feedback Area */}
          {lastMessage && (
            <div className="mt-8 p-6 bg-gradient-to-br from-yellow-50 to-orange-50 border border-yellow-200 rounded-2xl animate-fade-in-up shadow-sm relative overflow-hidden">
               <div className="absolute -right-4 -top-4 text-yellow-100 opacity-50">
                  <PartyPopper size={100} />
               </div>
              <div className="flex items-start gap-4 relative z-10">
                <div className="bg-yellow-400 p-2 rounded-lg text-white shadow-sm">
                    <Bot size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-yellow-800 text-sm uppercase mb-1 tracking-wide">Mensagem Mágica da IA</h4>
                  <p className="text-gray-700 font-medium italic text-lg leading-relaxed">"{lastMessage}"</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VotingForm;