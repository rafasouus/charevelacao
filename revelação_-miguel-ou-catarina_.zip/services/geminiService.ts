import { GoogleGenAI } from "@google/genai";
import { Gender } from "../types";

const API_KEY = process.env.API_KEY || '';

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateFunPrediction = async (guestName: string, guess: Gender): Promise<string> => {
  if (!API_KEY) {
    return "Obrigado pelo seu palpite! (Adicione uma API Key para ver mensagens mágicas)";
  }

  const babyName = guess === Gender.BOY ? "Miguel" : "Catarina";
  const genderText = guess === Gender.BOY ? "menino" : "menina";

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `O convidado ${guestName} acha que o bebê será ${genderText} e se chamará ${babyName}. 
      Crie uma frase curta, rimada, engraçada e empolgante (máximo 20 palavras) em Português do Brasil agradecendo o voto e fazendo uma previsão divertida.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 } 
      }
    });

    return response.text || "Palpite registrado com sucesso! A cegonha está de olho!";
  } catch (error) {
    console.error("Error generating AI message:", error);
    return "Seu palpite foi registrado! A magia falhou, mas seu voto conta!";
  }
};