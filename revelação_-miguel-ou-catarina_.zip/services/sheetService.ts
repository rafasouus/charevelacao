import { Vote, Gender } from "../types";

export const fetchVotesFromSheet = async (scriptUrl: string): Promise<Vote[]> => {
  try {
    // For GET requests, Google Apps Script usually handles CORS redirects automatically
    const response = await fetch(scriptUrl);
    const data = await response.json();
    
    // Validate and map data just in case
    return data.map((item: any) => ({
      id: item.id || Math.random().toString(),
      name: item.name,
      guess: item.guess === "MIGUEL" || item.guess === "BOY" ? Gender.BOY : Gender.GIRL,
      timestamp: item.timestamp,
      aiMessage: item.aiMessage
    }));
  } catch (error) {
    console.error("Erro ao buscar dados da planilha:", error);
    return [];
  }
};

export const sendVoteToSheet = async (scriptUrl: string, vote: Vote): Promise<boolean> => {
  try {
    const payload = {
      timestamp: vote.timestamp,
      name: vote.name,
      guess: vote.guess === Gender.BOY ? "MIGUEL" : "CATARINA",
      aiMessage: vote.aiMessage
    };

    console.log("Enviando dados para planilha:", payload);

    // CRITICAL: Google Apps Script Web Apps have strict CORS policies.
    // 1. We use mode: 'no-cors' to allow the browser to send the POST request without reading the response.
    // 2. We use Content-Type: 'text/plain' to prevent the browser from triggering a CORS Preflight (OPTIONS) request, 
    //    which Google Apps Script does not support and causes the request to fail silently.
    // The Apps Script must use JSON.parse(e.postData.contents) to read this body.
    await fetch(scriptUrl, {
      method: "POST",
      mode: "no-cors",
      headers: {
        "Content-Type": "text/plain",
      },
      body: JSON.stringify(payload),
    });
    
    return true;
  } catch (error) {
    console.error("Erro ao enviar para planilha:", error);
    return false;
  }
};